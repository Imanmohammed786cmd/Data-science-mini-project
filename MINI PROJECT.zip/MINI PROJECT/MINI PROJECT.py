import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import os
import re

# Set custom loading page with logo
st.set_page_config(page_title="IMDB Data Dashboard", page_icon="🎬")


st.title("🎬 IMDB Data Visualization Dashboard")

@st.cache_data
def load_data():
    file_path = "Merged_Genres.csv"
    if not os.path.exists(file_path):
        st.error("Error: Dataset file not found!")
        return pd.DataFrame()
    
    df = pd.read_csv(file_path, encoding="ISO-8859-1")  # Fix encoding issue
    df.columns = df.columns.str.lower().str.strip()
    
    required_columns = {'title', 'rating', 'votes', 'genre', 'duration'}
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        st.error(f"Error: Missing columns in dataset: {missing_columns}")
        return pd.DataFrame()
    
    df.dropna(subset=['rating', 'votes', 'duration', 'genre'], inplace=True)
    
    # Convert votes like "5K" to 5000
    def convert_votes(v):
        if isinstance(v, str):
            v = v.lower().replace('k', '000').replace('m', '000000')
        return pd.to_numeric(v, errors='coerce')
    
    df['votes'] = df['votes'].apply(convert_votes).fillna(0).astype(int)
    df['rating'] = pd.to_numeric(df['rating'], errors='coerce').fillna(0)
    
    def convert_duration(duration):
        match = re.match(r'(?:(\d+)h\s*)?(?:(\d+)m)?', str(duration))
        if match:
            hours = int(match.group(1)) if match.group(1) else 0
            minutes = int(match.group(2)) if match.group(2) else 0
            return hours * 60 + minutes
        return None
    
    df['duration'] = df['duration'].apply(convert_duration).fillna(0).astype(int)
    
    return df

df = load_data()
if df.empty:
    st.stop()

# Sidebar Filters
st.sidebar.header("🔍 Filters")
selected_genre = st.sidebar.selectbox("Select Genre", ["All"] + sorted(df['genre'].unique()))
min_rating, max_rating = st.sidebar.slider("Select Rating Range", float(df['rating'].min()), float(df['rating'].max()), (float(df['rating'].min()), float(df['rating'].max())))
min_duration, max_duration = st.sidebar.slider("Select Duration Range (mins)", int(df['duration'].min()), int(df['duration'].max()), (int(df['duration'].min()), int(df['duration'].max())))

votes_min = int(df['votes'].min())
votes_max = int(df['votes'].max())
if votes_min == votes_max:
    votes_min, votes_max = 0, votes_max + 1  
min_votes, max_votes = st.sidebar.slider("Select Votes Range", votes_min, votes_max, (votes_min, votes_max))

@st.cache_data
def filter_data(df, genre, min_rating, max_rating, min_duration, max_duration, min_votes, max_votes):
    filtered_df = df[
        (df['rating'] >= min_rating) & (df['rating'] <= max_rating) &
        (df['duration'] >= min_duration) & (df['duration'] <= max_duration) &
        (df['votes'] >= min_votes) & (df['votes'] <= max_votes)
    ]
    if genre != "All":
        filtered_df = filtered_df[filtered_df['genre'] == genre]
    return filtered_df

filtered_df = filter_data(df, selected_genre, min_rating, max_rating, min_duration, max_duration, min_votes, max_votes)

st.header("🏆 Top 10 Movies by Rating and Voting Counts")
top_movies = filtered_df.sort_values(by=['rating', 'votes'], ascending=[False, False]).head(10)
st.dataframe(top_movies[['title', 'rating', 'votes']])

st.header("🎭 Genre Distribution")
genre_counts = filtered_df['genre'].value_counts().reset_index()
genre_counts.columns = ['genre', 'count']
fig = px.bar(genre_counts, x='genre', y='count')
st.plotly_chart(fig)

st.header("⏳ Average Duration by Genre")
duration_avg = filtered_df.groupby('genre')['duration'].mean().reset_index()
fig = px.bar(duration_avg, x='duration', y='genre', orientation='h')
st.plotly_chart(fig)

st.header("📊 Voting Trends by Genre")
voting_trends = filtered_df.groupby('genre', as_index=False)['votes'].mean()
fig = px.histogram(voting_trends, x='genre', y='votes', title='Voting Trends by Genre', nbins=20)
st.plotly_chart(fig)

st.header("🏆 Rating Distribution")
fig = px.histogram(filtered_df, x='rating', nbins=20)
st.plotly_chart(fig)

st.header("⭐ Genre-Based Rating Leaders")
top_rated_per_genre = filtered_df.loc[filtered_df.groupby('genre')['rating'].idxmax()][['genre', 'title', 'rating']]
st.dataframe(top_rated_per_genre)

st.header("🎥 Duration Extremes")
shortest = filtered_df.nsmallest(1, 'duration')
longest = filtered_df.nlargest(1, 'duration')
st.write("**Shortest Movie:**", shortest[['title', 'duration']])
st.write("**Longest Movie:**", longest[['title', 'duration']])

st.header("📊 Ratings by Genre")
rating_heatmap = filtered_df.pivot_table(index='genre', values='rating', aggfunc='mean')
fig, ax = plt.subplots()
sns.heatmap(rating_heatmap, annot=True, cmap='coolwarm', ax=ax)
st.pyplot(fig)

st.header("🔍 Correlation Analysis")
fig = px.scatter(filtered_df, x='votes', y='rating', trendline='ols')
st.plotly_chart(fig)

# Most Popular Genres by Voting Pie Chart
st.header("🍿 Most Popular Genres by Voting")
genre_votes = filtered_df.groupby('genre')['votes'].sum().reset_index()
fig = px.pie(genre_votes, names='genre', values='votes', title="Most Popular Genres by Voting")
st.plotly_chart(fig)
